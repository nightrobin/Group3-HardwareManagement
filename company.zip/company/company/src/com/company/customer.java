package com.company;

import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;
import java.util.Date;

public class customer extends loginPage{

    private static Object Font;
    private static DefaultTableModel tempModel;
    private static DefaultTableModel model = new DefaultTableModel();
    private static DefaultTableModel orderModel = new DefaultTableModel();

        public static void main(String[] args) {

            ///MAIN FRAME
            JFrame frame = new JFrame("Customer Page");
            frame.setSize(1100, 650);
            frame.setResizable(false);
            frame.setVisible(true);
            frame.setLocationRelativeTo(null);
            frame.setLayout(null);

            ///TEXTS IN USER INTERFACE
            JLabel labelHardwareStore;
            labelHardwareStore = new JLabel("HARDWARE STORE");
            labelHardwareStore.setBounds(30, 60, 1100 , 50);
            labelHardwareStore.setFont(new Font("Arial", java.awt.Font.PLAIN, 50));
            labelHardwareStore.setForeground(Color.white);
            frame.add(labelHardwareStore);

            labelHardwareStore = new JLabel("Welcome, USER");
            labelHardwareStore.setBounds(400, 200, 1100 , 50);
            labelHardwareStore.setFont(new Font("Arial", java.awt.Font.BOLD, 50));
            labelHardwareStore.setForeground(Color.WHITE);
            frame.add(labelHardwareStore);

            labelHardwareStore = new JLabel("This is _____________ HARDWARE STORE");
            labelHardwareStore.setBounds(400, 300, 1100 , 50);
            labelHardwareStore.setFont(new Font("Arial", java.awt.Font.BOLD, 20));
            labelHardwareStore.setForeground(Color.WHITE);
            frame.add(labelHardwareStore);

            labelHardwareStore = new JLabel("Address: Muralla Street, Intramuros, Manila");
            labelHardwareStore.setBounds(400, 325, 1100 , 50);
            labelHardwareStore.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
            labelHardwareStore.setForeground(Color.WHITE);
            frame.add(labelHardwareStore);

            labelHardwareStore = new JLabel("Mobile Number: 09927630175");
            labelHardwareStore.setBounds(400, 350, 1100 , 50);
            labelHardwareStore.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
            labelHardwareStore.setForeground(Color.WHITE);
            frame.add(labelHardwareStore);

            //LOG OUT BUTTON
            JButton logoutBtn = new JButton("LOG OUT");
            logoutBtn.setFont(new Font("Arial", java.awt.Font.BOLD,25));
            logoutBtn.setBounds(900, 30, 200 , 120);
            logoutBtn.setBackground(new Color(0x042E56));
            logoutBtn.setForeground(Color.WHITE);
            frame.add(logoutBtn);

            //PRODUCT BUTTON
            JButton productBtn = new JButton("PRODUCTS");
            productBtn.setFont(new Font("Arial", java.awt.Font.BOLD,25));
            productBtn.setBounds(0, 250, 300 , 100);
            productBtn.setBackground(new Color(0x161642));
            productBtn.setForeground(Color.WHITE);
            frame.add(productBtn);

            //CATEGORY BUTTON
            JButton categoryBtn = new JButton("CATEGORIES");
            categoryBtn.setFont(new Font("Arial", java.awt.Font.BOLD,25));
            categoryBtn.setBounds(0, 400, 300 , 100);
            categoryBtn.setBackground(new Color(0x161642));
            categoryBtn.setForeground(Color.WHITE);
            frame.add(categoryBtn);



            //DESIGNS/PANELS
            JPanel panel = new JPanel();
            panel.setBounds(0,30,1100,120);
            panel.setBackground(new Color(0x042E56));
            frame.add(panel);


            panel = new JPanel();
            panel.setBounds(0,120,350,500);
            panel.setBackground(new Color(0x09142D));
            frame.add(panel);

            panel = new JPanel();
            panel.setBounds(350,180,750,390);
            panel.setBackground(new Color(0x042E56));
            frame.add(panel);

            ///main
            Main admin = new Main();

            JTable orderTable = new JTable();
            JScrollPane orderSp = new JScrollPane();

            Object[] column = {"Category","Name","Quantity","Price"};
            Object[] ordRow = new Object[7];
            orderModel.setColumnIdentifiers(column);
            orderTable.setModel(orderModel);
            orderSp.setViewportView(orderTable);
            orderTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

            //PRODUCT BUTTON ACTION LISTENER - PAG PININDOT LALABAS NA CODE
            productBtn.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    ///TABLE FOR EXAMPLE, sample lang to, pwede idelete depende sa code na ilalagay nyo
                    JScrollPane sp = new JScrollPane();
                    sp.setBounds(350, 200, 800, 400);
                    sp.setBorder(new EmptyBorder(15, 100, 10, 5));
                    frame.add(sp);

                    JTable table2 = new JTable();

                    Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};

                    if(tempModel!=null){
                        model = tempModel;
                    }
                    else{
                        tempModel=null;
                    }

                    Object[] row = new Object[7];
                    model.setColumnIdentifiers(column);
                    table2.setModel(model);
                    sp.setViewportView(table2);
                    table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                    Main.table(model);

                    JButton atcBtn = new JButton("<html><center>ADD TO<br>CART</center></html>");
                    atcBtn.setFont(new Font("Arial", java.awt.Font.BOLD,11));
                    atcBtn.setBounds(0, 50, 100 , 50);
                    atcBtn.setBackground(new Color(0x161642));
                    atcBtn.setForeground(Color.WHITE);
                    sp.add(atcBtn);

                    JButton prBtn = new JButton("<html><center>PURCHASE<br>FORM</center></html>");
                    prBtn.setFont(new Font("Arial", java.awt.Font.BOLD,11));
                    prBtn.setBounds(0, 100, 100 , 50);
                    prBtn.setBackground(new Color(0x161642));
                    prBtn.setForeground(Color.WHITE);
                    sp.add(prBtn);

                    atcBtn.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            int selR = table2.getSelectedRow();
                            if (selR < 0) {
                                JOptionPane.showMessageDialog(null, "Please Select product first.");
                            } else {
                                JFrame atcFrame = new JFrame("Add to Cart");
                                atcFrame.setSize(600, 300);
                                atcFrame.setLayout(null);
                                atcFrame.setVisible(true);
                                atcFrame.setLocationRelativeTo(null);

                                ///ID Text
                                JLabel quan = new JLabel("ID", JLabel.RIGHT);
                                quan.setText("Quantity:");
                                quan.setBounds(0, 75, 130, 30);
                                atcFrame.add(quan);

                                ////These are the text fields na makikita sa Add frame
                                JTextField quanTxt = new JTextField();
                                quanTxt.setBounds(200, 75, 200, 30);
                                atcFrame.add(quanTxt);

                                JButton addBtn = new JButton("Add");
                                addBtn.setBounds(210, 150, 150, 50);
                                addBtn.setBackground(new Color(10, 120, 80));
                                addBtn.setForeground(Color.WHITE);
                                atcFrame.add(addBtn);

                                JButton cnBtn = new JButton("Cancel");
                                cnBtn.setBounds(400, 150, 150, 50);
                                cnBtn.setBackground(new Color(120, 10, 10));
                                cnBtn.setForeground(Color.WHITE);
                                atcFrame.add(cnBtn);

                                addBtn.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent actionEvent) {
                                        int rowNum, itemQuan, quantity, price;
                                        String cat, pName;

                                        rowNum = table2.getSelectedRow();
                                        itemQuan = Integer.parseInt(table2.getModel().getValueAt(rowNum, 5).toString());
                                        price = Integer.parseInt(table2.getModel().getValueAt(rowNum, 4).toString());

                                        cat = table2.getModel().getValueAt(rowNum, 1).toString();
                                        pName = table2.getModel().getValueAt(rowNum, 2).toString();

                                        if (quanTxt.getText().equals("")) {
                                            JOptionPane.showMessageDialog(null, "Please enter valid quantity.");
                                            quanTxt.setText("");
                                        } else {
                                            quantity = Integer.parseInt(quanTxt.getText());
                                            if (quantity <= 0 || quantity > itemQuan) {
                                                JOptionPane.showMessageDialog(null, "Please enter valid quantity.");
                                                quanTxt.setText("");
                                            } else {
                                                price = quantity * price;
                                                model.setValueAt(itemQuan - quantity, rowNum, 5);
                                                ordRow[0] = cat;
                                                ordRow[1] = pName;
                                                ordRow[2] = quantity;
                                                ordRow[3] = price;
                                                orderModel.addRow(ordRow);
                                                JOptionPane.showMessageDialog(null, "Added to cart!");
                                                quanTxt.setText("");
                                            }
                                        }
                                    }
                                });

                                cnBtn.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent actionEvent) {
                                        atcFrame.dispose();
                                    }
                                });
                            }
                        }
                    });

                    prBtn.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            int tabR = orderTable.getRowCount();

                            if (tabR == 0) {
                                JOptionPane.showMessageDialog(null, "Your cart is empty.");
                            } else {
                                JFrame purchFrame = new JFrame("Order List");
                                purchFrame.setSize(1100, 500);
                                purchFrame.setResizable(false);
                                purchFrame.setVisible(true);
                                purchFrame.setLayout(null);
                                purchFrame.setLocationRelativeTo(null);
                                purchFrame.getContentPane().setBackground(new Color(0x161642));

                                orderSp.setBounds(550, 50, 900, 400);
                                orderSp.setBorder(new EmptyBorder(15, 100, 10, 5));
                                purchFrame.add(orderSp);

                                JButton selBtn = new JButton("<html><center>SELECT ANOTHER<br>PRODUCT</html>");
                                selBtn.setBounds(100, 100, 150, 100);
                                selBtn.setBackground(new Color(10, 120, 80));
                                selBtn.setForeground(Color.WHITE);
                                purchFrame.add(selBtn);

                                JButton remBtn = new JButton("<html><center>REMOVE<br>PRODUCT</html>");
                                remBtn.setBounds(300, 100, 150, 100);
                                remBtn.setBackground(new Color(10, 120, 80));
                                remBtn.setForeground(Color.WHITE);
                                purchFrame.add(remBtn);

                                JButton buyBtn = new JButton("<html><center>BUY<br>NOW</html>");
                                buyBtn.setBounds(200, 250, 150, 100);
                                buyBtn.setBackground(new Color(10, 120, 80));
                                buyBtn.setForeground(Color.WHITE);
                                purchFrame.add(buyBtn);

                                selBtn.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent actionEvent) {
                                        purchFrame.dispose();
                                    }
                                });

                                remBtn.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent actionEvent) {
                                        int rowSel = orderTable.getSelectedRow();
                                        int quan, row=0, quan2=0;

                                        if (rowSel < 0) {
                                            JOptionPane.showMessageDialog(null, "Please Select product first.");
                                        } else {
                                            quan = Integer.parseInt(orderModel.getValueAt(rowSel, 2).toString());
                                            for(int i=0; i<orderModel.getRowCount();i++){
                                                if(model.getValueAt(i, 2).equals(orderModel.getValueAt(i, 1))){
                                                    quan2 = Integer.parseInt(model.getValueAt(i, 5).toString());
                                                    row = i;
                                                }
                                            }

                                            model.setValueAt(quan + quan2, row, 5);
                                            orderModel.removeRow(rowSel);
                                        }
                                    }
                                });

                                buyBtn.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent actionEvent) {
                                        int subtotal = 0, rowCo = orderTable.getRowCount();
                                        double discount, total;

                                        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                        Date date = new Date();

                                        JFrame recFrame = new JFrame("E-Receipt");
                                        recFrame.setSize(400, 900);
                                        recFrame.getContentPane().setBackground(new Color(0x161642));
                                        recFrame.setResizable(false);
                                        recFrame.setLayout(null);
                                        recFrame.setVisible(true);
                                        recFrame.setLocationRelativeTo(null);

                                        JLabel receiptLbl;
                                        receiptLbl = new JLabel("<html><center>HARDWARE<br>STORE</center></html>");
                                        receiptLbl.setBounds(110, 20, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.PLAIN, 30));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel("<html><center>Muralla Street, Intramuros, Manila<br><br>Mobile Number: 09927630175<br>__________________________________</center></html>");
                                        receiptLbl.setBounds(10, 120, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        JLabel listLbl;
                                        int yAx = 220;

                                        for (int i = 0; i < rowCo; i++) {
                                            listLbl = new JLabel(orderModel.getValueAt(i, 1).toString());
                                            listLbl.setBounds(15, yAx, 400, 50);
                                            listLbl.setFont(new Font("Arial", java.awt.Font.PLAIN, 20));
                                            listLbl.setForeground(Color.WHITE);
                                            recFrame.add(listLbl);

                                            listLbl = new JLabel("x" + orderModel.getValueAt(i, 2).toString());
                                            listLbl.setBounds(100, yAx, 400, 50);
                                            listLbl.setFont(new Font("Arial", java.awt.Font.PLAIN, 20));
                                            listLbl.setForeground(Color.WHITE);
                                            recFrame.add(listLbl);

                                            listLbl = new JLabel("Php" + orderModel.getValueAt(i, 3).toString());
                                            listLbl.setBounds(250, yAx, 400, 50);
                                            listLbl.setFont(new Font("Arial", java.awt.Font.PLAIN, 20));
                                            listLbl.setForeground(Color.WHITE);
                                            recFrame.add(listLbl);

                                            subtotal += Integer.parseInt(orderModel.getValueAt(i, 3).toString());
                                            yAx += 50;
                                        }

                                        receiptLbl = new JLabel("__________________________________");
                                        receiptLbl.setBounds(10, yAx += 50, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel("Subtotal:");
                                        receiptLbl.setBounds(15, yAx += 50, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel("Php " + subtotal);
                                        receiptLbl.setBounds(250, yAx, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        discount = subtotal * .15;

                                        receiptLbl = new JLabel("Discount (15%):");
                                        receiptLbl.setBounds(15, yAx += 50, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel("Php " + discount);
                                        receiptLbl.setBounds(250, yAx, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        total = subtotal - discount;

                                        receiptLbl = new JLabel("Total:");
                                        receiptLbl.setBounds(15, yAx += 50, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel("Php " + total);
                                        receiptLbl.setBounds(250, yAx, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);

                                        receiptLbl = new JLabel(date.toString());
                                        receiptLbl.setBounds(50, yAx + 100, 400, 100);
                                        receiptLbl.setFont(new Font("Arial", java.awt.Font.ITALIC, 20));
                                        receiptLbl.setForeground(Color.WHITE);
                                        recFrame.add(receiptLbl);
                                    }
                                });
                            }
                        }
                    });

                }});

            logoutBtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    frame.dispose();
                    loginPage.main(args);
                }
            });

            //CATEGORY BUTTON ACTION LISTENER -
            categoryBtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    JFrame frame2 = new JFrame("Category Section");
                    frame2.setSize(1100, 650);
                    frame2.setResizable(false);
                    frame2.setVisible(true);
                    frame2.setLocationRelativeTo(null);
                    frame2.setLayout(null);

                    JLabel labelCategories;
                    labelCategories = new JLabel("Product Categories");
                    labelCategories.setBounds(30, 60, 1100 , 50);
                    labelCategories.setFont(new Font("Arial", java.awt.Font.PLAIN, 25));
                    labelCategories.setForeground(Color.white);
                    frame2.add(labelCategories);

                    JPanel panel = new JPanel();
                    panel.setBounds(0,30,1100,90);
                    panel.setBackground(new Color(0x042E56));
                    frame2.add(panel);

                    //HOME BUTTON
                    JButton HomeBtn = new JButton("Home");
                    HomeBtn.setFont(new Font("Arial", java.awt.Font.BOLD,25));
                    HomeBtn.setBounds(900, 30, 200 , 90);
                    HomeBtn.setBackground(new Color(0x042E56));
                    HomeBtn.setForeground(Color.WHITE);
                    frame2.add(HomeBtn);

                    //GARDENING BUTTON
                    JButton gardeningBtn = new JButton("GARDENING");
                    gardeningBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    gardeningBtn.setBounds(0, 165, 300 , 60);
                    gardeningBtn.setBackground(new Color(0x161642));
                    gardeningBtn.setForeground(Color.WHITE);
                    frame2.add(gardeningBtn);

                    //ELECTRICAL BUTTON
                    JButton electricalBtn = new JButton("ELECTRICAL");
                    electricalBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    electricalBtn.setBounds(0, 230, 300 , 60);
                    electricalBtn.setBackground(new Color(0x161642));
                    electricalBtn.setForeground(Color.WHITE);
                    frame2.add(electricalBtn);

                    //lIGHTING BUTTON
                    JButton lightingBtn = new JButton("LIGHTING");
                    lightingBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    lightingBtn.setBounds(0, 295, 300 , 60);
                    lightingBtn.setBackground(new Color(0x161642));
                    lightingBtn.setForeground(Color.WHITE);
                    frame2.add(lightingBtn);

                    //PLUMBING BUTTON
                    JButton plumbingBtn = new JButton("PLUMBING");
                    plumbingBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    plumbingBtn.setBounds(0, 360, 300 , 60);
                    plumbingBtn.setBackground(new Color(0x161642));
                    plumbingBtn.setForeground(Color.WHITE);
                    frame2.add(plumbingBtn);

                    //HANDHELD TOOLS BUTTON
                    JButton handheldToolsBtn = new JButton("HANDHELD TOOLS");
                    handheldToolsBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    handheldToolsBtn.setBounds(0, 425, 300 , 60);
                    handheldToolsBtn.setBackground(new Color(0x161642));
                    handheldToolsBtn.setForeground(Color.WHITE);
                    frame2.add(handheldToolsBtn);

                    //MACHINE TOOLS BUTTON
                    JButton machineToolsBtn = new JButton("MACHINE TOOLS");
                    machineToolsBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                    machineToolsBtn.setBounds(0, 490, 300 , 60);
                    machineToolsBtn.setBackground(new Color(0x161642));
                    machineToolsBtn.setForeground(Color.WHITE);
                    frame2.add(machineToolsBtn);

                    //GARDENING BUTTON ACTION LISTENER
                    gardeningBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Gardening")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);
                        }});

                    //ELECTRICAL BUTTON ACTION LISTENER
                    electricalBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Electrical")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);

                        }});

                    //LIGHTING BUTTON ACTION LISTENER
                    lightingBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Lighting")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);

                        }});

                    //PLUMBING BUTTON ACTION LISTENER
                    plumbingBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Plumbing")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);

                        }});

                    //MACHINE TOOLS BUTTON ACTION LISTENER
                    machineToolsBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Machine Tools")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);

                        }});

                    //HANDHELD TOOLS BUTTON ACTION LISTENER
                    handheldToolsBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            ///TABLE FOR PRODUCTS
                            JScrollPane sp = new JScrollPane();
                            sp.setBounds(350, 165, 800, 320);
                            sp.setBorder(new EmptyBorder(15, 5, 10, 5));
                            frame2.add(sp);

                            JTable table2 = new JTable();
                            DefaultTableModel model = new DefaultTableModel();
                            Object[] column = {"ID", "Category", "Name", "Brand", "Price", "Quantity", "Description"};
                            Object[] row = new Object[7];
                            model.setColumnIdentifiers(column);
                            table2.setModel(model);
                            sp.setViewportView(table2);
                            table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                            if (tempModel!=null) {
                                int rowC = tempModel.getRowCount();
                                for (int i = 0; i < rowC; i++) {
                                    if(tempModel.getValueAt(i, 1).equals("Handheld Tools")){
                                        row[0] = tempModel.getValueAt(i, 0);
                                        row[1] = tempModel.getValueAt(i, 1);
                                        row[2] = tempModel.getValueAt(i, 2);
                                        row[3] = tempModel.getValueAt(i, 3);
                                        row[4] = tempModel.getValueAt(i, 4);
                                        row[5] = tempModel.getValueAt(i, 5);
                                        row[6] = tempModel.getValueAt(i, 6);
                                        model.addRow(row);
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            else{
                                tempModel = null;
                            }

                            //ADD TO CART BUTTON
                            JButton addToCartBtn = new JButton("ADD TO CART");
                            addToCartBtn.setFont(new Font("Arial", java.awt.Font.BOLD,15));
                            addToCartBtn.setBounds(900, 500, 180 , 60);
                            addToCartBtn.setBackground(new Color(0x421616));
                            addToCartBtn.setForeground(Color.WHITE);
                            frame2.add(addToCartBtn);

                        }});

                    //HOME BUTTON ACTION LISTENER
                    HomeBtn.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e) {

                            //BACK TO CUSTOMER PAGE
                            JFrame frame = new JFrame();
                            frame.setVisible(false);
                            frame2.dispose();

                        }});
                }
            });
        }

    public static void table(DefaultTableModel model) {
        customer.tempModel = model;
    }
}
