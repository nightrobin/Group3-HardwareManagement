package com.company;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Main extends loginPage{

    private static DefaultTableModel tempModel;

    public static void main(String[] args) {
        String Category;
        String name;
        String brand;
        float price;
        int quantity;
        String description;
        String id;


/////Eto yung First Frame na lilitaw kung saan nandito na yung Table at datas

        ///Jframe Set-up
        JFrame frame = new JFrame("Manage Products");
        frame.setSize(1100, 650);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);

        //title
        JLabel adminlabel;
        adminlabel = new JLabel("ADMIN PAGE");
        adminlabel.setBounds(30, 60, 1100 , 50);
        adminlabel.setFont(new Font("Arial", java.awt.Font.PLAIN, 50));
        adminlabel.setForeground(Color.white);
        frame.add(adminlabel);

        //design
        JPanel pd = new JPanel();
        pd.setBounds(0,30,1100,120);
        pd.setBackground(new Color(0x570A12));
        frame.add(pd);


        ///Add button
        JButton addtoolBtn = new JButton("ADD PRODUCT");
        addtoolBtn.setBounds(0, 200, 200 , 100);
        addtoolBtn.setFont(new Font("Arial", java.awt.Font.BOLD,20));
        addtoolBtn.setBackground(new Color(10,120,80));
        addtoolBtn.setForeground(Color.WHITE);
        frame.add(addtoolBtn);

        //Edit button
        JButton edittoolBtn = new JButton("EDIT PRODUCT");
        edittoolBtn.setBounds(0, 320, 200 , 100);
        edittoolBtn.setFont(new Font("Arial", java.awt.Font.BOLD,20));
        edittoolBtn.setBackground(new Color(255,180,0));
        edittoolBtn.setForeground(Color.WHITE);
        frame.add(edittoolBtn);

        //Remove button
        JButton removetoolBtn = new JButton("REMOVE");
        removetoolBtn.setBounds(0, 440, 200 , 100);
        removetoolBtn.setBackground(new Color(255,20,30));
        removetoolBtn.setFont(new Font("Arial", java.awt.Font.BOLD,20));
        removetoolBtn.setForeground(Color.WHITE);
        frame.add(removetoolBtn);

        JButton logoutBtn = new JButton("LOG OUT");
        logoutBtn.setFont(new Font("Arial", java.awt.Font.BOLD,25));
        logoutBtn.setBounds(900, 30, 200 , 120);
        logoutBtn.setBackground(new Color(0x570A12));
        logoutBtn.setForeground(Color.WHITE);
        frame.add(logoutBtn);

        pd = new JPanel();
        pd.setBounds(0,120,250,500);
        pd.setBackground(new Color(0x252424));
        frame.add(pd);

        pd = new JPanel();
        pd.setBounds(250,190,850,390);
        pd.setBackground(new Color(0x2C2929));
        frame.add(pd);

        ///Table Set-up
        JScrollPane sp = new JScrollPane();
        sp.setBounds(250,235,830,300);
        sp.setBorder(new EmptyBorder(15,100,10,5));
        frame.add(sp);

        JTable table1 = new JTable();
        DefaultTableModel model = new DefaultTableModel();

        Object[] column = {"ID","Category","Name","Brand","Price","Quantity","Description"};
        Object[] row = new Object[7];
        model.setColumnIdentifiers(column);
        table1.setModel(model);
        sp.setViewportView(table1);
        table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        //updating table info from
        if (tempModel!=null){
            int rowC = tempModel.getRowCount();
            for(int i = 0; i<rowC; i++){
                row[0] = tempModel.getValueAt(i,0);
                row[1] = tempModel.getValueAt(i,1);
                row[2] = tempModel.getValueAt(i,2);
                row[3] = tempModel.getValueAt(i,3);
                row[4] = tempModel.getValueAt(i,4);
                row[5] = tempModel.getValueAt(i,5);
                row[6] = tempModel.getValueAt(i,6);
                model.addRow(row);
            }

        }

        ///Action na mangyayare pag pinindot and EDIT BUTTON (MARAVILLA)
        edittoolBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int rows = table1.getRowCount();
                int selR = table1.getSelectedRow();
                String name, des, brand, price, quant, id, cat;

                if (rows==0){
                    JOptionPane.showMessageDialog(null, "The table is empty. Please add products first.");
                }
                else if(selR<0){
                    JOptionPane.showMessageDialog(null, "Please Select product first.");
                }
                else{
                    id = model.getValueAt(selR, 0).toString();
                    cat = model.getValueAt(selR, 1).toString();
                    name = model.getValueAt(selR, 2).toString();
                    brand = model.getValueAt(selR, 3).toString();
                    price = model.getValueAt(selR, 4).toString();
                    quant = model.getValueAt(selR, 5).toString();
                    des = model.getValueAt(selR, 6).toString();

                ///New frame for adding data in the table
                    JFrame frame3 = new JFrame("Edit Product Listing");
                    frame3.setSize(400, 600);
                    frame3.setLayout(null);
                    frame3.setVisible(true);
                    frame3.setLocationRelativeTo(null);

                    ///ID Text
                    JLabel idlabel = new JLabel("ID", JLabel.RIGHT);
                    idlabel.setText("ID:");
                    idlabel.setBounds(-30,25,130,30);
                    frame3.add(idlabel);

                    /////Category Text
                    JLabel categorylabel = new JLabel("Category", JLabel.RIGHT);
                    categorylabel.setText("Category:");
                    categorylabel.setBounds(-50,60,150,50);
                    frame3.add(categorylabel);

                    /////Name Text
                    JLabel namelabel = new JLabel("Name", JLabel.RIGHT);
                    namelabel.setText("Name:");
                    namelabel.setBounds(-30,120,130,30);
                    frame3.add(namelabel);

                    /////Brand Text
                    JLabel brandlabel = new JLabel("Brand", JLabel.RIGHT);
                    brandlabel.setText("Brand:");
                    brandlabel.setBounds(-30,170,130,30);
                    frame3.add(brandlabel);

                    /////Price Text
                    JLabel pricelabel = new JLabel("Price", JLabel.RIGHT);
                    pricelabel.setText("Price:");
                    pricelabel.setBounds(-30,220,130,30);
                    frame3.add(pricelabel);

                    /////Quantity Text
                    JLabel quantitylabel = new JLabel("Quantity", JLabel.RIGHT);
                    quantitylabel.setText("Quantity:");
                    quantitylabel.setBounds(-30,268,130,30);
                    frame3.add(quantitylabel);

                    /////Description Text
                    JLabel descriptionlabel = new JLabel("Description", JLabel.RIGHT);
                    descriptionlabel.setText("Description:");
                    descriptionlabel.setBounds(-30,313,130,30);
                    frame3.add(descriptionlabel);

                    ////These are the text fields na makikita sa Add frame
                    JTextField idtextField = new JTextField();
                    idtextField.setBounds(150, 25, 200, 30);
                    frame3.add(idtextField);
                    idtextField.setText(id);

                    idtextField.addKeyListener(new KeyAdapter() {
                        public void keyTyped(KeyEvent e) {
                            char c = e.getKeyChar();
                            if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                                e.consume();  // if it's not a number, ignore the event
                            }
                        }
                    });

                    String languages[]={"Gardening","Electrical","Lighting","Plumbing","Handheld Tools","Machine Tools"};
                    final JComboBox cb=new JComboBox(languages);
                    cb.setBounds(150, 77,200,20);
                    frame3.add(cb);
                    cb.setSelectedItem(cat);

                    JTextField nametextField = new JTextField();
                    nametextField.setBounds(150, 120, 200, 30);
                    frame3.add(nametextField);
                    nametextField.setText(name);

                    JTextField brandtextField = new JTextField();
                    brandtextField.setBounds(150, 170, 200, 30);
                    frame3.add(brandtextField);
                    brandtextField.setText(brand);

                    JTextField pricetextField = new JTextField();
                    pricetextField.setBounds(150, 220, 200, 30);
                    frame3.add(pricetextField);
                    pricetextField.setText(price);

                    pricetextField.addKeyListener(new KeyAdapter() {
                        public void keyTyped(KeyEvent e) {
                            char c = e.getKeyChar();
                            if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                                e.consume();  // if it's not a number, ignore the event
                            }
                        }
                    });

                    JTextField qntytextField = new JTextField();
                    qntytextField.setBounds(150, 270, 200, 30);
                    frame3.add(qntytextField);
                    qntytextField.setText(quant);

                    qntytextField.addKeyListener(new KeyAdapter() {
                        public void keyTyped(KeyEvent e) {
                            char c = e.getKeyChar();
                            if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                                e.consume();  // if it's not a number, ignore the event
                            }
                        }
                    });

                    JTextField descriptextField = new JTextField();
                    descriptextField.setBounds(150, 320, 200, 60);
                    frame3.add(descriptextField);
                    descriptextField.setText(des);

                    ////Edit button
                    JButton editBtn = new JButton("SAVE");
                    editBtn.setBounds(210, 420, 150 , 50);
                    editBtn.setBackground(new Color(10,120,80));
                    editBtn.setForeground(Color.WHITE);
                    frame3.add(editBtn);

                    editBtn.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            if (idtextField.getText().equals("")||cb.getSelectedItem().equals("")||nametextField.getText().equals("")||brandtextField.getText().equals("")||pricetextField.getText().equals("")||qntytextField.getText().equals("")||descriptextField.getText().equals(""))
                            {
                                JOptionPane.showMessageDialog(null, "Please Enter all information");
                            }
                            else{
                                model.setValueAt(idtextField.getText(), selR, 0);
                                model.setValueAt(cb.getSelectedItem(), selR, 1);
                                model.setValueAt(nametextField.getText(), selR, 2);
                                model.setValueAt(brandtextField.getText(), selR, 3);
                                model.setValueAt(pricetextField.getText(), selR, 4);
                                model.setValueAt(qntytextField.getText(), selR, 5);
                                model.setValueAt(descriptextField.getText(), selR, 6);
                            }
                        }
                    });

                    ////Cancel button
                    JButton cancelBtn = new JButton("Cancel");
                    cancelBtn.setBounds(20, 420, 150 , 50);
                    cancelBtn.setBackground(new Color(255,20,30));
                    cancelBtn.setForeground(Color.WHITE);
                    frame3.add(cancelBtn);

                    cancelBtn.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            frame3.dispose();
                        }
                    });
                }

            }
        });

        ///Action na mangyayare pag pinindot and Add button
        addtoolBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ///New frame for adding data in the table
                JFrame frame2 = new JFrame("Add Product");
                frame2.setSize(400, 600);
                frame2.setLayout(null);
                frame2.setVisible(true);
                frame2.setLocationRelativeTo(null);

                ///ID Text
                JLabel idlabel = new JLabel("ID", JLabel.RIGHT);
                idlabel.setText("ID:");
                idlabel.setBounds(-30,25,130,30);
                frame2.add(idlabel);

                /////Category Text
                JLabel categorylabel = new JLabel("Category", JLabel.RIGHT);
                categorylabel.setText("Category:");
                categorylabel.setBounds(-50,60,150,50);
                frame2.add(categorylabel);

                /////Name Text
                JLabel namelabel = new JLabel("Name", JLabel.RIGHT);
                namelabel.setText("Name:");
                namelabel.setBounds(-30,120,130,30);
                frame2.add(namelabel);

                /////Brand Text
                JLabel brandlabel = new JLabel("Brand", JLabel.RIGHT);
                brandlabel.setText("Brand:");
                brandlabel.setBounds(-30,170,130,30);
                frame2.add(brandlabel);

                /////Price Text
                JLabel pricelabel = new JLabel("Price", JLabel.RIGHT);
                pricelabel.setText("Price:");
                pricelabel.setBounds(-30,220,130,30);
                frame2.add(pricelabel);

                /////Quantity Text
                JLabel quantitylabel = new JLabel("Quantity", JLabel.RIGHT);
                quantitylabel.setText("Quantity:");
                quantitylabel.setBounds(-30,268,130,30);
                frame2.add(quantitylabel);

                /////Description Text
                JLabel descriptionlabel = new JLabel("Description", JLabel.RIGHT);
                descriptionlabel.setText("Description:");
                descriptionlabel.setBounds(-30,313,130,30);
                frame2.add(descriptionlabel);

                ////These are the text fields na makikita sa Add frame
                JTextField idtextField = new JTextField();
                idtextField.setBounds(150, 25, 200, 30);
                frame2.add(idtextField);

                idtextField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                            e.consume();  // if it's not a number, ignore the event
                        }
                    }
                });

                String languages[]={"Gardening","Electrical","Lighting","Plumbing","Handheld Tools","Machine Tools"};
                final JComboBox cb=new JComboBox(languages);
                cb.setBounds(150, 77,200,20);
                frame2.add(cb);


                JTextField nametextField = new JTextField();
                nametextField.setBounds(150, 120, 200, 30);
                frame2.add(nametextField);


                JTextField brandtextField = new JTextField();
                brandtextField.setBounds(150, 170, 200, 30);
                frame2.add(brandtextField);


                JTextField pricetextField = new JTextField();
                pricetextField.setBounds(150, 220, 200, 30);
                frame2.add(pricetextField);

                pricetextField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                            e.consume();  // if it's not a number, ignore the event
                        }
                    }
                });


                JTextField qntytextField = new JTextField();
                qntytextField.setBounds(150, 270, 200, 30);
                frame2.add(qntytextField);

                qntytextField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                            e.consume();  // if it's not a number, ignore the event
                        }
                    }
                });

                JTextField descriptextField = new JTextField();
                descriptextField.setBounds(150, 320, 200, 60);
                frame2.add(descriptextField);

                ////Add button
                JButton addBtn = new JButton("Add");
                addBtn.setBounds(210, 420, 150 , 50);
                addBtn.setBackground(new Color(10,120,80));
                addBtn.setForeground(Color.WHITE);
                frame2.add(addBtn);



                ////Eto-yung pag-add ng mga datas from textfields to table
                addBtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        ////Lagyan natin ng if statement na hindi nya tatanggapin pag mayroong kulang sa mga textfield
                        if (idtextField.getText().equals("")||cb.getSelectedItem().equals("")||nametextField.getText().equals("")||brandtextField.getText().equals("")||pricetextField.getText().equals("")||qntytextField.getText().equals("")||descriptextField.getText().equals(""))
                        {
                            JOptionPane.showMessageDialog(null, "Please Enter all information");
                        }
                        else{
                            int rows = model.getRowCount();
                            String tempID;
                            boolean isTaken = false;

                            for(int i=0; i<rows; i++){
                                tempID = model.getValueAt(i, 0).toString();
                                if(tempID.equals(idtextField.getText())){
                                    isTaken = true;
                                }
                            }

                            if(isTaken){
                                JOptionPane.showMessageDialog(null, "The Product ID is already taken.");
                            }
                            else{
                                row[0] = idtextField.getText();
                                row[1] = cb.getSelectedItem();
                                row[2] = nametextField.getText();
                                row[3] = brandtextField.getText();
                                row[4] = pricetextField.getText();
                                row[5] = qntytextField.getText();
                                row[6] = descriptextField.getText();
                                model.addRow(row);

                                ////Dito magrereset ang mga TextField after nya mag-add ng data sa table
                                idtextField.setText("");
                                cb.setSelectedItem("");
                                nametextField.setText("");
                                brandtextField.setText("");
                                pricetextField.setText("");
                                qntytextField.setText("");
                                descriptextField.setText("");
                                JOptionPane.showMessageDialog(null, "Tool Added Successfully");
                            }
                        }


                    }
                });

                ////Cancel button
                JButton cancelBtn = new JButton("Cancel");
                cancelBtn.setBounds(20, 420, 150 , 50);
                cancelBtn.setBackground(new Color(255,20,30));
                cancelBtn.setForeground(Color.WHITE);
                frame2.add(cancelBtn);

                ////Cancel button will exit the add button frame
                cancelBtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        frame2.dispose();
                    }
                });

            }
        });

        logoutBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ///main
                frame.dispose();
                customer.table(model);
                loginPage.main(args);
            }
        });

        removetoolBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i = table1.getSelectedRow();
                if(i >= 0){
                    model.removeRow(i);
                    JOptionPane.showMessageDialog(null, "Tool Removed Successfully");
                }
                else{
                    JOptionPane.showMessageDialog(null, "Please Select a Tool That You Want To Remove");
                }
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void table(DefaultTableModel model) {
        Main.tempModel = model;
    }
}