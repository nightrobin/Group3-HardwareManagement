package com.company;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class loginPage{

    public static void main(String[] args) {
        //MAIN WINDOW
        JFrame loginWindow = new JFrame("Log-in");
        loginWindow.setSize(700,400);
        loginWindow.setLayout(null);
        loginWindow.setVisible(true);
        loginWindow.setLocationRelativeTo(null);

        //Labels
        JLabel title = new JLabel("Welcome to the Hardware Virtual Interface!");
        title.setBounds(225, 20, 300,50);
        loginWindow.add(title);

        JLabel username = new JLabel("Username:");
        username.setBounds(150, 95, 150,50);
        loginWindow.add(username);

        JLabel password = new JLabel("Password:");
        password.setBounds(150, 125, 150, 50);
        loginWindow.add(password);

        JLabel menuText = new JLabel("Please select an option:");
        menuText.setBounds(150, 75, 150, 20);
        loginWindow.add(menuText);


        //TEXT FIELDS
        JTextField usernameField = new JTextField(50);
        usernameField.setBounds(220, 110, 300, 20);
        loginWindow.add(usernameField);

        JPasswordField passwordField = new JPasswordField(50);
        passwordField.setBounds(220, 140, 300, 20);
        loginWindow.add(passwordField);

        //DROP DOWN MENU
        String[] menuChoices = {"Customer", "Administrator"};
        JComboBox dropDownMenuButton = new JComboBox(menuChoices);
        dropDownMenuButton.setBounds(295, 75, 90, 20);
        dropDownMenuButton.setLayout(null);
        dropDownMenuButton.setVisible(true);
        loginWindow.add(dropDownMenuButton);


        //LOG-IN BUTTON
        JButton login = new JButton("LOG-IN");
        login.setBounds(280, 200, 100, 20);
        loginWindow.add(login);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usernameText;
                String passwordText;
                Object menu;
                usernameText = usernameField.getText();
                passwordText = passwordField.getText();
                menu = dropDownMenuButton.getSelectedItem();
                if (usernameText.equals("customer") && passwordText.equals("12345") && menu.equals("Customer")){
                    JOptionPane.showMessageDialog(loginWindow, "You are successfully logged in. Welcome, customer.");
                    loginWindow.dispose();
                    customer.main(args);
                }
                else if (usernameText.equals("administrator") && passwordText.equals("12345") && menu.equals("Administrator")){
                    JOptionPane.showMessageDialog(loginWindow, "You are successfully logged in. Welcome, administrator.");
                    loginWindow.dispose();
                    Main.main(args);
                }
                else {
                    JOptionPane.showMessageDialog(loginWindow, "Wrong username or password.");
                }
            }
        });



    }
}